<?php

declare(strict_types=1);

echo "Application is running.\n";
