# Take-Home Practical – PHP Application

You may modify any provided files if needed. Please document why.


## Overview

Briefly describe what the application does.

## Requirements

- Docker
- Docker Compose

## Setup

Explain how to start the application.

## Usage

Describe available endpoints or functionality.

## Assumptions & Tradeoffs

Document any assumptions made or tradeoffs chosen.