-- MariaDB-compatible schema
-- This schema is intentionally minimal and may be extended as needed.
CREATE TABLE
    assets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        department VARCHAR(100) NOT NULL,
        status VARCHAR(50) NOT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL
    );

INSERT INTO
    assets (name, department, status, created_at, updated_at)
VALUES
    -- IT Department
    (
        'Laptop A',
        'IT',
        'active',
        '2024-01-10 08:30:00',
        '2024-01-10 08:30:00'
    ),
    (
        'Laptop B',
        'IT',
        'active',
        '2023-06-12 09:15:00',
        '2024-02-01 10:00:00'
    ),
    (
        'Desktop C',
        'IT',
        'inactive',
        '2022-03-20 14:00:00',
        '2022-08-10 11:30:00'
    ),
    (
        'Printer D',
        'IT',
        'active',
        '2023-01-05 11:45:00',
        '2023-11-01 16:30:00'
    ),
    (
        'Switch E',
        'IT',
        'retired',
        '2020-09-18 13:10:00',
        '2021-01-15 09:00:00'
    ),
    -- Facilities Department
    (
        'Projector F',
        'Facilities',
        'active',
        '2023-10-15 09:00:00',
        '2023-10-20 14:12:00'
    ),
    (
        'HVAC Controller G',
        'Facilities',
        'active',
        '2021-04-22 10:30:00',
        '2022-04-22 10:30:00'
    ),
    (
        'Generator H',
        'Facilities',
        'inactive',
        '2019-07-01 08:00:00',
        '2020-01-10 15:45:00'
    ),
    -- Education Department
    (
        'Tablet I',
        'Education',
        'inactive',
        '2022-08-01 10:00:00',
        '2022-08-01 10:00:00'
    ),
    (
        'Chromebook J',
        'Education',
        'active',
        '2023-08-15 09:20:00',
        '2024-01-05 12:00:00'
    ),
    (
        'Smartboard K',
        'Education',
        'active',
        '2021-11-03 14:40:00',
        '2023-02-18 09:10:00'
    ),
    (
        'Document Camera L',
        'Education',
        'retired',
        '2018-05-10 13:25:00',
        '2019-06-01 08:45:00'
    ),
    -- Media Department
    (
        'Camera M',
        'Media',
        'retired',
        '2021-05-12 13:20:00',
        '2021-12-01 09:15:00'
    ),
    (
        'Microphone N',
        'Media',
        'active',
        '2024-02-01 11:00:00',
        '2024-02-01 11:00:00'
    ),
    (
        'Mixer O',
        'Media',
        'inactive',
        '2022-02-14 16:30:00',
        '2022-06-01 10:10:00'
    ),
    -- Administration Department
    (
        'Server P',
        'Administration',
        'active',
        '2023-03-01 07:45:00',
        '2024-01-20 08:30:00'
    ),
    (
        'NAS Q',
        'Administration',
        'active',
        '2022-09-12 10:15:00',
        '2023-09-12 10:15:00'
    ),
    (
        'Backup Appliance R',
        'Administration',
        'inactive',
        '2020-01-05 09:00:00',
        '2020-12-31 23:59:00'
    );