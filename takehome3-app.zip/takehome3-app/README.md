# Existing PHP Asset Listing Application

This is a small PHP application that displays a list of assets stored in a MariaDB database.

The application is intentionally simple and is meant to represent an existing internal tool. It is functional but not heavily abstracted or over-engineered.

## What the Application Does

- Connects to a MariaDB database
- Retrieves asset records
- Displays them in a basic HTML table

The main listing logic lives in:
- `src/assets.php` – database query logic
- `src/index.php` – rendering the list

## Requirements

- Docker
- Docker Compose

## Running the Application

From the project root:

```bash

docker-compose up --build

```
