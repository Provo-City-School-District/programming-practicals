<?php

$pdo = new PDO(
    'mysql:host=db;dbname=app;charset=utf8mb4',
    'app',
    'app',
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]
);
