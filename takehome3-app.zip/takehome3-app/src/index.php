<?php

$assets = require __DIR__ . '/assets.php';
?>
<!DOCTYPE html>
<html>

<head>
    <title>Assets</title>
</head>

<body>
    <h1>Asset List</h1>

    <table border="1" cellpadding="5">
        <tr>
            <th>Name</th>
            <th>Department</th>
            <th>Status</th>
            <th>Created</th>
        </tr>

        <?php foreach ($assets as $asset): ?>
            <tr>
                <td><?= htmlspecialchars($asset['name']) ?></td>
                <td><?= htmlspecialchars($asset['department']) ?></td>
                <td><?= htmlspecialchars($asset['status']) ?></td>
                <td><?= $asset['created_at'] ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>

</html>