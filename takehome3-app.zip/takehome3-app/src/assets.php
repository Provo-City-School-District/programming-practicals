<?php

require_once __DIR__ . '/db.php';

$sql = "SELECT * FROM assets ORDER BY created_at DESC";
$stmt = $pdo->query($sql);
$assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

return $assets;
